import { Component, OnInit } from '@angular/core';
import { NewsApiService } from './news-api.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-news-headlines',
  templateUrl: './news-headlines.component.html',
  styleUrls: ['./news-headlines.component.css']
})
export class NewsHeadlinesComponent implements OnInit  {
  mArticles: Array<any>;
  mSources: Array<any>;

  constructor(private newsapi: NewsApiService) { }
    //console.log('News Headlines component constructor called');
    http: HttpClient;

  api_key = '2dbb8c981ad64c5897d941b4bc346062';
  
 ngOnInit() {
    this.newsapi.initArticles().subscribe(data => this.mArticles = data['articles']);
    //load news sources
    this.newsapi.initSources().subscribe(data => this.mSources = data['sources']);  
  }
  searchArticles(source) {
    console.log("selected source is: " + source);
    this.newsapi.getArticlesByID(source).subscribe(data => this.mArticles = data['articles']);
    }

    Saveemployee4() {

      return this.http.get('http://localhost:8080/user/Fav' + this.api_key);
    }
}
