import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http'
import { map } from 'rxjs/operators';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})



export class SignupComponent implements OnInit {

  render3: boolean;
  ren3 = true;
  temp = false;
 
  
  user: Object = []
  constructor(public httpdata: Http) { }

  ngOnInit() { }

  signup(firstname, lastname, username, password, email, mobile, prefLang) {
    this.user = [
      {
        "firstName": firstname,
        "lastName": lastname,
        "username": username,
        "password": password,
        "email": email,
        "mobile": mobile,
        "preferredLanguage": prefLang
      }
    ]


    this.httpdata.post('http://localhost:8080/user/register', this.user[0], null)
      .pipe(map(
        (response: Response) => response.text()

      )).subscribe((data) => {
        console.log(data)
      }

    )
   


  }
}

